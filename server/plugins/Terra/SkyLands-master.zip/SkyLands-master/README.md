![picture](https://github.com/Gray-Falcon/picture/blob/main/Skylands.png?raw=true)

> **THIS PACK IS STILL WORK IN PROGRESS AND SHOULD NOT BE USED IN PRODUCTION YET**

Skylands pack is still in the testing stage, and balancing issues and bugs may be prevalent. As long as this warning is still here, this pack is not completed yet.

## Demo world
You can download singleplayer friendly, pregenerated 10k world from here: comming soon


## Credits
Skylands was made possible only through the help and support from the PolyhedralDev team, as well as the default Overworld config packaged with Terra, where a lot of edited configs from can be found in various assets in Skylands. You can check out the pack here: https://github.com/PolyhedralDev/TerraOverworldConfig

## Installing this pack
ID of SkyLands is SKYLANDS . You can see how to install this pack in this VIDEO >>> https://www.youtube.com/watch?v=-PqtdgBclx4

## Bugs and Features
Im hardly working on this!

## SkyLands Discord
https://discord.gg/99DUces7Gh
This is my Discord server. Come and discuss the lore of Skylands, make suggestions, report bugs, and maybe even join and play on the official Skylands Minecraft server!

[!!FOR SUPPORT JOIN POLYDEV DS!!]
